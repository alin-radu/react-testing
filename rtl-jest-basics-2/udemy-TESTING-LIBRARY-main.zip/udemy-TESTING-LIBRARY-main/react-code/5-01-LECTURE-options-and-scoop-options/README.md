**NOTE:** You will need to run

```
npm install msw axios@^0.27
```

after copying the code to `src`, for dependencies that don't come with create-react-app.
