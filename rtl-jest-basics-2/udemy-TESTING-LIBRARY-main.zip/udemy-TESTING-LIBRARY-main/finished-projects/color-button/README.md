# Color Button

This project accompanies the Udemy course [Testing React with Jest and Testing Library](https://www.udemy.com/course/react-testing-library/).

## Mock-Ups

### 1. Red Button

![Red Button](https://github.com/bonnie/udemy-TESTING-LIBRARY/blob/master/finished-projects/color-button/mock-ups/1-red-button.png)

### 2. Blue Button

![Blue Button](https://github.com/bonnie/udemy-TESTING-LIBRARY/blob/master/finished-projects/color-button/mock-ups/2-blue-button.png)

### 3. Checkbox

![Checkbox](https://github.com/bonnie/udemy-TESTING-LIBRARY/blob/master/finished-projects/color-button/mock-ups/3-checkbox.png)

### 4. Checkbox Label

![Checkbox Label](https://github.com/bonnie/udemy-TESTING-LIBRARY/blob/master/finished-projects/color-button/mock-ups/4-checkbox-label.png)

### 5. Gray Disabled Button

![Gray Disabled Button](https://github.com/bonnie/udemy-TESTING-LIBRARY/blob/master/finished-projects/color-button/mock-ups/5-gray-disabled-button.png)
